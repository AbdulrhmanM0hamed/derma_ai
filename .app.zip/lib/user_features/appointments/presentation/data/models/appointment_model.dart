// Re-export the appointment model for easier imports
export 'appointment_model.dart';
