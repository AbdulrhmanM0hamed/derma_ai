import 'package:flutter/material.dart';
import 'ai_skin_diagnosis.dart';

class AiDiagnosisPage extends StatelessWidget {
  const AiDiagnosisPage({super.key});

  @override
  Widget build(BuildContext context) {
    return AiSkinDiagnosis();
  }
}
