package com.example.derma_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
